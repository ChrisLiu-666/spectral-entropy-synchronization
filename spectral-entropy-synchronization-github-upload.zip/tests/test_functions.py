import unittest

import networkx as nx
import numpy as np

from esg import (
    entropy_sensitivity_from_matrix,
    entropy_sensitivity_scores,
    esg_ranking,
)
from spectral_entropy import spectral_entropy_curve, spectral_entropy_descriptors


def _matrix_entropy(matrix: np.ndarray, beta: float) -> float:
    eigenvalues = np.linalg.eigvalsh(matrix)
    entropy, _ = spectral_entropy_curve(eigenvalues, np.array([beta]))
    return float(entropy[0])


class SpectralEntropyAndESGTests(unittest.TestCase):
    def test_entropy_at_small_beta_is_near_log2_n(self):
        eigenvalues = np.array([0.0, 1.0, 3.0, 4.0])
        entropy, heat = spectral_entropy_curve(eigenvalues, np.array([1e-10]))
        self.assertTrue(np.isclose(entropy[0], 2.0, atol=1e-10))
        self.assertGreaterEqual(heat[0], 0.0)

    def test_entropy_descriptors_are_finite(self):
        result = spectral_entropy_descriptors(nx.cycle_graph(8))
        self.assertTrue(np.isfinite(result.entropy).all())
        self.assertTrue(np.isfinite(result.specific_heat).all())
        self.assertGreater(result.entropy_area, 0.0)

    def test_esg_scores_sum_to_zero(self):
        scores = entropy_sensitivity_scores(nx.path_graph(7), beta=1.3)
        self.assertTrue(np.isclose(sum(scores.values()), 0.0, atol=1e-12))

    def test_esg_score_matches_finite_difference(self):
        graph = nx.path_graph(6)
        beta = 0.9
        node = 2
        score = entropy_sensitivity_scores(graph, beta=beta)[node]

        laplacian = nx.laplacian_matrix(graph).astype(float).toarray()
        perturbation = np.zeros_like(laplacian)
        perturbation[node, node] = 1.0
        epsilon = 1e-6
        numerical = (
            _matrix_entropy(laplacian + epsilon * perturbation, beta)
            - _matrix_entropy(laplacian, beta)
        ) / epsilon
        self.assertTrue(np.isclose(score, numerical, rtol=2e-5, atol=1e-8))

    def test_esg_ranking_uses_principal_submatrix_each_round(self):
        graph = nx.path_graph(8)
        result = esg_ranking(graph, n_select=4)
        self.assertEqual(len(result.ranking), 4)

        matrix = nx.laplacian_matrix(graph).astype(float).toarray()
        remaining_nodes = list(graph.nodes())
        for round_ in result.rounds:
            scores = entropy_sensitivity_from_matrix(matrix, round_.beta_star)
            selected_index = int(np.argmax(scores))
            self.assertEqual(round_.selected_node, remaining_nodes[selected_index])
            self.assertTrue(
                np.isclose(round_.selected_score, scores[selected_index])
            )
            matrix = np.delete(
                np.delete(matrix, selected_index, axis=0), selected_index, axis=1
            )
            remaining_nodes.pop(selected_index)


if __name__ == "__main__":
    unittest.main()
