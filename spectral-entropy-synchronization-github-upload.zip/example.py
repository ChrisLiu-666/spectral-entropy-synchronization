"""Minimal example for the public spectral-entropy and ESG functions."""

import networkx as nx

from esg import esg_ranking
from spectral_entropy import spectral_entropy_descriptors


graph = nx.watts_strogatz_graph(n=30, k=4, p=0.2, seed=7)

entropy = spectral_entropy_descriptors(graph, mu=0.05)
print(f"beta* = {entropy.beta_star:.6g}")
print(f"S_e* = {entropy.entropy_star:.6g}")
print(f"S_A = {entropy.entropy_area:.6g}")

esg = esg_ranking(graph, n_select=5)
print("Top five nodes by ESG:", esg.ranking)
print("Round-specific beta*:", [round_.beta_star for round_ in esg.rounds])
print("Selected ESG scores:", [round_.selected_score for round_ in esg.rounds])
