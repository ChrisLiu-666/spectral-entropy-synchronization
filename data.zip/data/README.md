# Network datasets

The six files in this directory are the connected, simple, undirected,
unweighted networks used in the manuscript's pinning-control experiments.
Each non-empty line contains two integer node identifiers separated by
whitespace. Node identifiers are zero-based in the supplied files.

| File | Nodes | Edges | Mean degree |
| --- | ---: | ---: | ---: |
| `Celegans.txt` | 297 | 2,148 | 14.4646 |
| `Jazz.txt` | 198 | 2,742 | 27.6970 |
| `Email.txt` | 1,133 | 5,451 | 9.6222 |
| `NS_GC.txt` | 379 | 914 | 4.8232 |
| `WS_500_0.3.txt` | 500 | 1,000 | 4.0000 |
| `ER_500_0.01.txt` | 496 | 1,202 | 4.8468 |

The empirical networks are obtained from the public sources cited in the
accompanying manuscript. The WS and ER files are the representative generated
instances used in the reported experiments. For generated instances that were
not connected, the target connected component reported in the manuscript is
provided here.

## Loading

```python
import networkx as nx

G = nx.read_edgelist(
    "data/Celegans.txt",
    nodetype=int,
    create_using=nx.Graph,
)
```

The loader should treat the files as simple undirected graphs and should not
infer edge weights from node identifiers.
